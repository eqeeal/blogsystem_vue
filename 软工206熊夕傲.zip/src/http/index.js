import userHttp from "./modules/userHttp";
//...
export default{
    userHttp
}
