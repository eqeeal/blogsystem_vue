import request from "../requst.js"
function login(data) {
    return request({
        url: '/user/login',
        params:data
    })
}
//得到所有用户数据
function getall() {
    return request({
        url: '/user/findAll',
        method:"get"
    })
 }
 //删除所有用户
 function delUser(data){
    return request({
        url: '/user/delete',
        method:"post",
        data
        //或者data：data
    })
 }
 //批量刪除
 function delUsers(data){
    return request({
        url:"/user/delUsers",
        method:"post",
        data
    })
 }
 function updateUser(data){
    return request({
        url:"/user/update",
        method:"post",
        data
    })
 }

export default {
    login,
    getall,
    delUser,
    delUsers,
    updateUser
}