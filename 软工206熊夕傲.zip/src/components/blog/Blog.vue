<template>
  <div>
    博客管理
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>