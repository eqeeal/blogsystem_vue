<template>
  <div style="display:flex">
    <div class="edit-form">
      <h3>站点信息</h3>
      <el-form 
        :label-position="labelPosition"
        label-width="10px"
        :model="formzhandian">
        <el-form-item label="站点名称" class="item">
          <el-input v-model="formzhandian.name"  style="width:300px"></el-input>
        </el-form-item>
        <el-form-item label="站点描述" class="item">
          <el-input v-model="formzhandian.describe " style="width:300px"></el-input>
        </el-form-item>
        <el-form-item label="站点logo" class="item">
          <el-input v-model="formzhandian.logo" style="width:300px"></el-input>
        </el-form-item>
        <el-form-item label="favicon.ico" class="item">
          <el-input v-model="formzhandian.ico"  style="width:300px"></el-input>
        </el-form-item>
      </el-form>
      <el-button type="danger" round  style=" margin-left: 180px">确认修改</el-button>
    </div>



    <div class="edit-form" >
      <h3>个人信息</h3>
      <el-form 
        :label-position="labelPosition"
        label-width="10px"
        :model="formzhandian">
        <el-form-item label="个人头像" class="item">
          <el-input v-model="formgeren.avatar" style="width:300px" ></el-input>
        </el-form-item>
        <el-form-item label="个人名称" class="item">
          <el-input v-model="formgeren.name" style="width:300px"></el-input>
        </el-form-item>
        <el-form-item label="个人邮箱" class="item">
          <el-input v-model="formgeren.email" style="width:300px"></el-input>
        </el-form-item>
      </el-form>
      <el-button type="danger" round  style=" margin-left: 180px">确认修改</el-button>
    </div>




    <div class="edit-form">
      <h3>底部设置</h3>
      <el-form 
        :label-position="labelPosition"
        label-width="10px"
        :model="formzhandian">
        <el-form-item label="底部About" class="item">
          <el-input v-model="formdibu.about" style="width:270px" ></el-input>
        </el-form-item>
        <el-form-item label="底部备案号" class="item">
          <el-input v-model="formdibu.beian" style="width:270px"></el-input>
        </el-form-item>
        <el-form-item label="底部Copy Right" class="item">
          <el-input v-model="formdibu.right" style="width:270px"></el-input>
        </el-form-item>
        <el-form-item label="底部Powered By" class="item">
          <el-input v-model="formdibu.powerby" style="width:270px"></el-input>
        </el-form-item>
        <el-form-item label="底部Powered By URL" class="item">
          <el-input v-model="formgeren.powerbyurl" style="width:270px"></el-input>
        </el-form-item>
      </el-form>
      <el-button type="danger" round style=" margin-left: 150px">确认修改</el-button>
    </div>
  </div>
</template>

<script>
export default {
  created(){
    this.getSystemById()
  },
  methods:{
    getSystemById(){
      axios({
          url:"http://localhost:8081/system/byId",
          method:"Get",
          success:function(res){
              console.log(res)
              this.formzhandian=res.data;
              alert(JSON.stringify(formzhandian))
          }
      })
   }
  },
  data() {
    return {
      labelPosition: "top",
      formzhandian: {
        name: "",
        describe: "",
        logo: "",
        ico:"",
      },
      formgeren: {
        avatar: "",
        name: "",
        email: "",
      },
      formdibu: {
        about: "",
        beian: "",
        copyRight: "",
        powerby: "",
        powerbyurl: "",
      },
      id:1,
    };
  },
};
</script>

<style>
.item .el-form-item__label{
    width: 200px;
    float: left;
    margin-left: 0px;
}
.edit-form {
  box-shadow: 0 0 30px #ccc;
  border-top: 5px solid rgb(71, 140, 220);
  border: 5px solid rgb(red, green, blue);
  width: 350px;
}

</style>