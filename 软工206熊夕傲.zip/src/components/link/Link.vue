<template>
  <div>
    友情链接
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>